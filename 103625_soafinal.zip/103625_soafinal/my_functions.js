function adder(x, y)
{
	var z = x + y;
	return z;
}